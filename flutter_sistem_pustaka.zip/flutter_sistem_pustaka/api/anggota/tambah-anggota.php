<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari request
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $alamat = $_POST['alamat'];
    $jenis_kelamin = $_POST['jenis_kelamin'];

    // Validasi input
    if (empty($nim) || empty($nama) || empty($email) || empty($password)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'NIM, Nama, Email, dan Password harus diisi'
        ]);
        exit;
    }

    // Cek apakah NIM atau email sudah terdaftar
    $query_check = "SELECT id FROM anggota WHERE nim = ? OR email = ? LIMIT 1";
    $stmt_check = $conn->prepare($query_check);
    $stmt_check->bind_param("ss", $nim, $email);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'NIM atau Email sudah terdaftar'
        ]);
        exit;
    }

    // Generate ID anggota
    $id = uniqid('AGT');

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert data anggota
    $query = "INSERT INTO anggota (id, nim, nama, email, password, alamat, jenis_kelamin) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssss", $id, $nim, $nama, $email, $hashed_password, $alamat, $jenis_kelamin);

    if ($stmt->execute()) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Anggota berhasil ditambahkan',
            'data' => [
                'id' => $id,
                'nim' => $nim,
                'nama' => $nama,
                'email' => $email,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin
            ]
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal menambahkan anggota: ' . $conn->error
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
