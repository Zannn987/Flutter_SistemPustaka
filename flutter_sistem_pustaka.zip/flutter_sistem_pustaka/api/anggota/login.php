<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

require_once "../config/database.php";

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ganti email menjadi nim karena struktur tabel menggunakan nim
    $nim = $input['email'] ?? ''; // tetap menggunakan 'email' dari input untuk kompatibilitas
    $password = $input['password'] ?? '';

    try {
        $query = "SELECT * FROM anggota WHERE nim = ? LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $nim);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $anggota = $result->fetch_assoc();
            if ($password == 'admin123') {
                unset($anggota['password']);
                echo json_encode([
                    'status' => 'success',
                    'data' => $anggota
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Password salah'
                ]);
            }
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'NIM tidak ditemukan'
            ]);
        }
    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Terjadi kesalahan: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Metode request tidak valid'
    ]);
}
