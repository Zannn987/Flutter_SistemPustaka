<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once '../config/database.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['nim']) || empty($data['password'])) {
        throw new Exception('NIM dan password wajib diisi');
    }

    $nim = mysqli_real_escape_string($conn, $data['nim']);
    $password = mysqli_real_escape_string($conn, $data['password']);

    $query = "SELECT * FROM anggota WHERE nim = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ss", $nim, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Login berhasil',
            'data' => [
                'id' => $row['id'],
                'nim' => $row['nim'],
                'nama' => $row['nama'],
                'alamat' => $row['alamat'],
                'jenis_kelamin' => $row['jenis_kelamin']
            ]
        ]);
    } else {
        throw new Exception('NIM atau password salah');
    }
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}

mysqli_close($conn);
