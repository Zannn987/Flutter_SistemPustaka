<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari request
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $stok = $_POST['stok'];

    // Validasi input
    if (empty($judul) || empty($pengarang) || empty($penerbit) || empty($tahun_terbit) || empty($stok)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Semua field harus diisi'
        ]);
        exit;
    }

    // Generate ID buku
    $id = uniqid('BK');

    // Insert data buku
    $query = "INSERT INTO buku (id, judul, pengarang, penerbit, tahun_terbit, stok) 
              VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssii", $id, $judul, $pengarang, $penerbit, $tahun_terbit, $stok);

    if ($stmt->execute()) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Buku berhasil ditambahkan',
            'data' => [
                'id' => $id,
                'judul' => $judul,
                'pengarang' => $pengarang,
                'penerbit' => $penerbit,
                'tahun_terbit' => $tahun_terbit,
                'stok' => $stok
            ]
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal menambahkan buku: ' . $conn->error
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
