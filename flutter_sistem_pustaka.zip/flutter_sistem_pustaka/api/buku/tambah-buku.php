<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include_once '../config/database.php';

try {
    // Debug: print raw input
    $raw_input = file_get_contents('php://input');
    error_log("Raw input: " . $raw_input);

    // Parse JSON
    $data = json_decode($raw_input, true);

    // Debug: print parsed data
    error_log("Parsed data: " . print_r($data, true));

    // Validasi JSON
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }

    // Validasi field
    $required_fields = ['nim', 'password', 'nama', 'jenis_kelamin'];
    $missing_fields = [];

    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            $missing_fields[] = $field;
        }
    }

    if (!empty($missing_fields)) {
        throw new Exception('Field berikut wajib diisi: ' . implode(', ', $missing_fields));
    }

    // Proses data
    $nim = mysqli_real_escape_string($conn, $data['nim']);
    $password = mysqli_real_escape_string($conn, $data['password']);
    $nama = mysqli_real_escape_string($conn, $data['nama']);
    $alamat = mysqli_real_escape_string($conn, $data['alamat'] ?? '');
    $jenis_kelamin = mysqli_real_escape_string($conn, $data['jenis_kelamin']);

    // ... kode selanjutnya sama ...

} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
