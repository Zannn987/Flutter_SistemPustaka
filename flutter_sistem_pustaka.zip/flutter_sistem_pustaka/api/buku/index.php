<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Query untuk mengambil semua data buku
    $query = "SELECT * FROM buku ORDER BY judul ASC";
    $result = $conn->query($query);

    if ($result) {
        $buku = array();
        while ($row = $result->fetch_assoc()) {
            $buku[] = array(
                'id' => $row['id'],
                'judul' => $row['judul'],
                'pengarang' => $row['pengarang'],
                'penerbit' => $row['penerbit'],
                'tahun_terbit' => $row['tahun_terbit'],
                'stok' => $row['stok']
            );
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'Data buku berhasil diambil',
            'data' => $buku
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal mengambil data buku'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
