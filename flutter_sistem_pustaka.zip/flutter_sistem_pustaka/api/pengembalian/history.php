<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Ambil parameter filter
    $anggota_id = isset($_GET['anggota_id']) ? $_GET['anggota_id'] : '';

    // Base query
    $query = "SELECT k.*, p.anggota_id, p.buku_id, 
              b.judul as judul_buku, a.nama as nama_anggota
              FROM pengembalian k
              JOIN peminjaman p ON k.peminjaman_id = p.id
              JOIN buku b ON p.buku_id = b.id
              JOIN anggota a ON p.anggota_id = a.id
              WHERE 1=1";

    $params = array();
    $types = "";

    // Tambahkan filter jika ada
    if (!empty($anggota_id)) {
        $query .= " AND p.anggota_id = ?";
        $params[] = $anggota_id;
        $types .= "s";
    }

    $query .= " ORDER BY k.tanggal_kembali DESC";

    // Prepare dan execute query
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $pengembalian = array();
        while ($row = $result->fetch_assoc()) {
            $pengembalian[] = array(
                'id' => $row['id'],
                'peminjaman_id' => $row['peminjaman_id'],
                'anggota_id' => $row['anggota_id'],
                'nama_anggota' => $row['nama_anggota'],
                'buku_id' => $row['buku_id'],
                'judul_buku' => $row['judul_buku'],
                'tanggal_kembali' => $row['tanggal_kembali'],
                'terlambat' => $row['terlambat'],
                'denda' => $row['denda']
            );
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'Data pengembalian berhasil diambil',
            'data' => $pengembalian
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal mengambil data pengembalian'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
