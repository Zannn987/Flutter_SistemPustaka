<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari request
    $peminjaman_id = $_POST['peminjaman_id'];
    $tanggal_kembali = isset($_POST['tanggal_kembali']) ? $_POST['tanggal_kembali'] : date('Y-m-d');

    // Validasi input
    if (empty($peminjaman_id)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'ID peminjaman harus diisi'
        ]);
        exit;
    }

    // Ambil data peminjaman
    $query = "SELECT p.*, b.judul as judul_buku 
              FROM peminjaman p
              JOIN buku b ON p.buku_id = b.id
              WHERE p.id = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $peminjaman_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $peminjaman = $result->fetch_assoc();

        // Hitung keterlambatan dan denda
        $tanggal_harus_kembali = new DateTime($peminjaman['tanggal_kembali']);
        $tanggal_pengembalian = new DateTime($tanggal_kembali);
        $selisih = $tanggal_pengembalian->diff($tanggal_harus_kembali);
        $terlambat = $tanggal_pengembalian > $tanggal_harus_kembali ? $selisih->days : 0;
        $denda = $terlambat * 1000; // Rp 1.000 per hari

        echo json_encode([
            'status' => 'success',
            'data' => [
                'peminjaman_id' => $peminjaman_id,
                'judul_buku' => $peminjaman['judul_buku'],
                'tanggal_pinjam' => $peminjaman['tanggal_pinjam'],
                'tanggal_harus_kembali' => $peminjaman['tanggal_kembali'],
                'tanggal_pengembalian' => $tanggal_kembali,
                'terlambat' => $terlambat,
                'denda' => $denda,
                'keterangan' => $terlambat > 0 ?
                    "Terlambat $terlambat hari, denda Rp " . number_format($denda, 0, ',', '.') :
                    "Tidak ada denda"
            ]
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Peminjaman tidak ditemukan'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
