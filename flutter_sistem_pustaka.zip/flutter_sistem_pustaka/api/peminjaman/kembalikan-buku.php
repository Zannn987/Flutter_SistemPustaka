<?php
require_once "../config/database.php";

try {
    // Ambil ID peminjaman
    $id = isset($_POST['id']) ? $_POST['id'] : '';

    if (empty($id)) {
        sendJSON([
            'status' => 'error',
            'message' => 'ID peminjaman tidak ditemukan'
        ], 400);
    }

    // Cek peminjaman
    $query = "SELECT p.*, b.id as buku_id 
             FROM peminjaman p 
             JOIN buku b ON p.buku_id = b.id 
             WHERE p.id = '$id'";

    $result = $conn->query($query);

    if (!$result || $result->num_rows === 0) {
        sendJSON([
            'status' => 'error',
            'message' => 'Peminjaman tidak ditemukan'
        ], 404);
    }

    $peminjaman = $result->fetch_assoc();

    // Update status peminjaman
    $tanggal_pengembalian = date('Y-m-d');
    $update_peminjaman = "UPDATE peminjaman 
                         SET status = 'dikembalikan',
                             tanggal_pengembalian = '$tanggal_pengembalian'
                         WHERE id = '$id'";

    if (!$conn->query($update_peminjaman)) {
        sendJSON([
            'status' => 'error',
            'message' => 'Gagal mengupdate status peminjaman'
        ], 500);
    }

    // Update stok buku
    $update_buku = "UPDATE buku 
                   SET stok = stok + 1 
                   WHERE id = '{$peminjaman['buku_id']}'";

    if (!$conn->query($update_buku)) {
        sendJSON([
            'status' => 'error',
            'message' => 'Gagal mengupdate stok buku'
        ], 500);
    }

    sendJSON([
        'status' => 'success',
        'message' => 'Buku berhasil dikembalikan'
    ]);
} catch (Exception $e) {
    sendJSON([
        'status' => 'error',
        'message' => 'Gagal mengembalikan buku: ' . $e->getMessage()
    ], 500);
}
