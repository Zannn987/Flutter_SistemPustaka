<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari request
    $anggota_id = $_POST['anggota_id'];
    $buku_id = $_POST['buku_id'];
    $tanggal_pinjam = date('Y-m-d'); // Tanggal hari ini
    $tanggal_kembali = date('Y-m-d', strtotime('+7 days')); // 7 hari dari sekarang

    // Validasi input
    if (empty($anggota_id) || empty($buku_id)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Semua field harus diisi'
        ]);
        exit;
    }

    // Cek ketersediaan buku
    $query_stok = "SELECT stok FROM buku WHERE id = ? LIMIT 1";
    $stmt_stok = $conn->prepare($query_stok);
    $stmt_stok->bind_param("s", $buku_id);
    $stmt_stok->execute();
    $result_stok = $stmt_stok->get_result();
    $buku = $result_stok->fetch_assoc();

    if ($buku['stok'] <= 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Buku tidak tersedia'
        ]);
        exit;
    }

    // Generate ID peminjaman
    $id = uniqid('PJM');

    // Mulai transaction
    $conn->begin_transaction();

    try {
        // Insert data peminjaman
        $query = "INSERT INTO peminjaman (id, anggota_id, buku_id, tanggal_pinjam, tanggal_kembali, status) 
                 VALUES (?, ?, ?, ?, ?, 'dipinjam')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssss", $id, $anggota_id, $buku_id, $tanggal_pinjam, $tanggal_kembali);
        $stmt->execute();

        // Update stok buku
        $query_update = "UPDATE buku SET stok = stok - 1 WHERE id = ?";
        $stmt_update = $conn->prepare($query_update);
        $stmt_update->bind_param("s", $buku_id);
        $stmt_update->execute();

        // Commit transaction
        $conn->commit();

        echo json_encode([
            'status' => 'success',
            'message' => 'Peminjaman berhasil dibuat',
            'data' => [
                'id' => $id,
                'tanggal_pinjam' => $tanggal_pinjam,
                'tanggal_kembali' => $tanggal_kembali
            ]
        ]);
    } catch (Exception $e) {
        // Rollback jika terjadi error
        $conn->rollback();
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal membuat peminjaman: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
