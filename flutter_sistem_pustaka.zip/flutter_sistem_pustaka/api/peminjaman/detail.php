<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Ambil ID peminjaman dari parameter URL
    $id = isset($_GET['id']) ? $_GET['id'] : '';

    if (empty($id)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'ID peminjaman tidak ditemukan'
        ]);
        exit;
    }

    // Query untuk mengambil detail peminjaman
    $query = "SELECT p.*, b.judul as judul_buku, b.pengarang, b.penerbit,
              a.nama as nama_anggota, a.email as email_anggota
              FROM peminjaman p
              JOIN buku b ON p.buku_id = b.id
              JOIN anggota a ON p.anggota_id = a.id
              WHERE p.id = ? LIMIT 1";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $peminjaman = $result->fetch_assoc();

        // Hitung keterlambatan jika status masih dipinjam
        if ($peminjaman['status'] == 'dipinjam') {
            $tanggal_kembali = new DateTime($peminjaman['tanggal_kembali']);
            $tanggal_sekarang = new DateTime();
            $selisih = $tanggal_sekarang->diff($tanggal_kembali);
            $terlambat = $tanggal_sekarang > $tanggal_kembali ? $selisih->days : 0;

            $peminjaman['keterlambatan'] = $terlambat;
            $peminjaman['denda'] = $terlambat * 1000; // Rp 1.000 per hari
        }

        echo json_encode([
            'status' => 'success',
            'data' => $peminjaman
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Peminjaman tidak ditemukan'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
