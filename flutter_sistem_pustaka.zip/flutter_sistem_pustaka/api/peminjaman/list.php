<?php
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Ambil parameter filter
    $anggota_id = isset($_GET['anggota_id']) ? $_GET['anggota_id'] : '';
    $status = isset($_GET['status']) ? $_GET['status'] : '';

    // Base query
    $query = "SELECT p.*, b.judul as judul_buku, a.nama as nama_anggota 
              FROM peminjaman p
              JOIN buku b ON p.buku_id = b.id
              JOIN anggota a ON p.anggota_id = a.id
              WHERE 1=1";
    $params = array();
    $types = "";

    // Tambahkan filter jika ada
    if (!empty($anggota_id)) {
        $query .= " AND p.anggota_id = ?";
        $params[] = $anggota_id;
        $types .= "s";
    }

    if (!empty($status)) {
        $query .= " AND p.status = ?";
        $params[] = $status;
        $types .= "s";
    }

    $query .= " ORDER BY p.tanggal_pinjam DESC";

    // Prepare dan execute query
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $peminjaman = array();
        while ($row = $result->fetch_assoc()) {
            $peminjaman[] = array(
                'id' => $row['id'],
                'anggota_id' => $row['anggota_id'],
                'nama_anggota' => $row['nama_anggota'],
                'buku_id' => $row['buku_id'],
                'judul_buku' => $row['judul_buku'],
                'tanggal_pinjam' => $row['tanggal_pinjam'],
                'tanggal_kembali' => $row['tanggal_kembali'],
                'status' => $row['status']
            );
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'Data peminjaman berhasil diambil',
            'data' => $peminjaman
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal mengambil data peminjaman'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
