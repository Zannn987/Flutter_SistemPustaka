<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

try {
    $nim = $_GET['nim'] ?? '';

    if (empty($nim)) {
        throw new Exception("NIM tidak ditemukan");
    }

    // Get peminjaman with book details
    $query = "SELECT p.*, b.judul as judul_buku, b.pengarang, b.penerbit,
              DATE_FORMAT(p.tanggal_pinjam, '%Y-%m-%d') as tanggal_pinjam,
              DATE_FORMAT(p.tanggal_kembali, '%Y-%m-%d') as tanggal_kembali,
              p.status, -- Tambahkan kolom status
              p.tanggal_pengembalian -- Tambahkan kolom tanggal_pengembalian jika diperlukan
              FROM peminjaman p 
              JOIN buku b ON p.buku_id = b.id 
              WHERE p.anggota_id IN (SELECT id FROM anggota WHERE nim = '$nim')
              ORDER BY p.tanggal_pinjam DESC";

    $result = $conn->query($query);

    if (!$result) {
        throw new Exception($conn->error);
    }

    $peminjaman = array();
    while ($row = $result->fetch_assoc()) {
        $peminjaman[] = array(
            'id' => $row['id'],
            'judul_buku' => $row['judul_buku'],
            'pengarang' => $row['pengarang'],
            'penerbit' => $row['penerbit'],
            'tanggal_pinjam' => $row['tanggal_pinjam'],
            'tanggal_kembali' => $row['tanggal_kembali'],
            'status' => $row['status'] ?? 'dipinjam', // Tambahkan status dengan nilai default
            'tanggal_pengembalian' => $row['tanggal_pengembalian'] // Tambahkan tanggal pengembalian
        );
    }

    echo json_encode([
        'status' => 'success',
        'message' => 'Data peminjaman berhasil diambil',
        'data' => $peminjaman
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal mengambil data peminjaman: ' . $e->getMessage()
    ]);
}

$conn->close();
